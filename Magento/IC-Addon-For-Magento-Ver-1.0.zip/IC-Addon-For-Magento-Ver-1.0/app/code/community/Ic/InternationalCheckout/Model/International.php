<?php
class Ic_InternationalCheckout_Model_International extends Varien_Object {


	
	

}
